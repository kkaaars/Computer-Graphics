opencv_version = "4.10.0.84"
contrib = False
headless = False
rolling = False
ci_build = True